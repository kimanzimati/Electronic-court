<!DOCTYPE html>
<?php
	include('connect.php');

	if($_GET[u])
	{
		$user = $_GET[u];
	}

?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electronic court</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700">

    <link rel="stylesheet" href="assets/css/Footer-Basic.css">

    <link rel="stylesheet" href="assets/css/Header-Blue.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/Registration-Form-with-Photo.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body background="assets/img/images.png">
    <div>
        <div class="header-blue">
            <nav class="navbar navbar-dark navbar-expand-md navigation-clean-search">
                <div class="container"><a class="navbar-brand" href="#">Electronic Court System</a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                    <div
                        class="collapse navbar-collapse" id="navcol-1">
                        <ul class="nav navbar-nav">
                            <li class="nav-item" role="presentation"><a class="nav-link active" href="casepage.php">Case</a></li>
                            <li class="dropdown show"><a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="true" href="filing.php">E-filing</a>
                                <div class="dropdown-menu show" role="menu"><a class="dropdown-item" role="presentation" href="filing.php">Case filing</a><a class="dropdown-item" role="presentation" href="hearingdetails.php">Hearing details</a><a class="dropdown-item" role="presentation" href="trackingform.php">Track case</a></div>
                            </li>
                        </ul>
                        <form class="form-inline mr-auto" target="_self">
                            <div class="form-group"><label for="search-field"><i class="fa fa-search"></i></label><input class="form-control search-field" type="search" name="search" id="search-field"></div>
                        </form><span class="navbar-text"> 
						<?php
							// global $session;
							if($_SESSION[session])
							{
								$thisSession= $_SESSION[session];
								$theName = $thisSession[thisUser];
								$rights = $thisSession[userRights];
								print $theName.' <a href="logout.php">Logout</a>';
							}
							else
							{
								print '<a href="login.php" class="login">Log In</a>';
							}
						?>
						
						</span><a class="btn btn-light action-button" role="button" href="form.php"> Sign Up</a></div>
        </div>
        </nav>
        <div class="container hero">
            <div class="row">
                <div class="col-12 col-lg-6 col-xl-5 offset-xl-1">
                    <h1>The revolution is here.</h1>
                    <p>The electronic court system allows people to be able to keep track of case details from the point of arrest until a verdict is issued by a judge. It also allows criminals to pay their court fines and store the transaction details.</p>
                    <button
                        class="btn btn-light btn-lg action-button" type="button">Learn More</button>
                </div>
                <div class="col-md-5 col-lg-5 offset-lg-1 offset-xl-0 d-none d-lg-block phone-holder"><img src="assets/img/images.png"></div>
            </div>
        </div>
    </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>