<!DOCTYPE HTML>
<?php
	include('connect.php');
	checkPoliceOfficer(); // This line only checks if the user is a police officer, if yes then they are knocked off the page...
	
	if(isset($_POST[action])&&$_POST[action]=='addTrackingDetails')
	{
		global $link;
		$national_id = addslashes($_POST[nationalID]);
		$case_number = addslashes($_POST[caseNumber]);
		
		$sql = "insert into courthearing(caseNumber,nationalID) value('$case_number','$national_id')";
		$result = mysql_query($sql,$link);
		if(!$result)
		{
			print "Error adding details to the system. ".mysql_error();
		}
		else
		{
			print "<h1>Data added successfully</h1>";
		}
	}
	
?>
<html>
<head>
  <title>Tracking Form</title>
<link rel='stylesheet' type='text/css' href='stylez.css'>
</head>
<body  background="images/background002.jpg">
      <hr>
      <?php
      	include('nav.php');
      
      ?>  
        <hr>
<table border=1px  width=900px>
	<?php
		// $_POST[searchCaseNumber], $_POST[action]
		if(isset($_POST[action])&&$_POST[action]=='searchThis')
		{
			global $link;
			if(isset($_POST[searchCaseNumber]))
			{
				print "<thead><th align='right'>CASE NUMBER</th><th align='right'>NATIONAL ID</th><th align='left'>POLICE STATION</th><th align='left'>OFFENCE</th><th align='left'>DEFENDANT</th><th align='right'>DATE OF ENTRY</th> </thead>";
				
				$searchThisCaseNumber = $_POST[searchCaseNumber];
				$sql = "select * from casse where caseNumber='$searchThisCaseNumber'";
				$result = mysql_query($sql,$link);
				if(!$result)
				{
					print "Error reading db. ".mysql_error();
				}
				$returnedRows = mysql_num_rows($result);
				if($returnedRows==0)
				{
					print "<h1>No case number matching your entry '".$searchThisCaseNumber."'</h1>";
				}
				else
				{
					while($row=mysql_fetch_array($result))
					{
						print "<tr class='odd'><td align='right'>".$row[caseNumber]." </td><td align='right'>".$row[nationalID]." </td><td align='left'>".$row[policeStation]." </td><td align='left'>".$row[offence]." </td><td>".$row[names]." </td><td align='right'>".$row[timeOfEntry]." </td></tr>";
					}
				}
			}
		}
	
	?>
</table><hr>
 <form method='post'>
	<?php
		// $_POST[searchCaseNumber], $_POST[action]
	?>
	<input type='hidden' name='action' value='searchThis'>
	<fieldset>
		<legend>Search Case Form</legend>
		<input type='text' value='' name='searchCaseNumber' placeholder='Case number' autofocus ><input class='submitBox' type='submit' value='Submit'>
	</fieldset>
 </form>
<hr> 
<a href='filing.php'>ADD NEW CASE DETAILS</a>
<?php
	include('footer.php');
?>
</body>
</html>