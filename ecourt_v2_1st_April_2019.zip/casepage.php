<!DOCTYPE HTML>
<?php
	include('connect.php');
	checkPoliceOfficer(); // This line only checks if the user is a police officer, if yes then they are knocked off the page...
	
	if(isset($_POST[action])&&$_POST[action]=='addTrackingDetails')
	{
		global $link;
		$national_id = addslashes($_POST[nationalID]);
		$case_number = addslashes($_POST[caseNumber]);
		$case_time = addslashes($_POST[caseTime]);
		$judge_number = addslashes($_POST[judgeNumber]);
		$prosecutor_number = addslashes($_POST[prosecutorNumber]);
		
		
		$sql = "insert into courthearing(caseNumber,nationalID,judgeNo,prosecutorNo,caseTime,dateOfEntry) value('$case_number','$national_id','$judge_number','$prosecutor_number','$case_time',CURDATE())";
		$result = mysql_query($sql,$link);
		if(!$result)
		{
			print "Error adding details to the system. ".mysql_error();
		}
		else
		{
			print "<h1>Data added successfully</h1>";
		}
	}
	
?>
<html>
<head>
  <title>Tracking Form</title>
<link rel='stylesheet' type='text/css' href='stylez.css'>


</head>
<body  background="images/background002.jpg">
      <hr>
      <?php
      	include('nav.php');
      ?>
<hr><p>
This is where the electronic court system will conduct case hearings. We are trying to deliver justice fast. Case hearings are held via Skype and we record the call. The judge will issue a case verdict and upload it along with the fine details.</p>
<hr>
<?php
	global $link;
	$sql = "select casse.offence, casse.nationalID AS national_id, casse.caseNumber, casse.policeStation, casse.names, casse.cellphone, casse.email, courthearing.judgeNo, courthearing.caseVerdict, courthearing.fine from courthearing, casse WHERE casse.caseNumber=courthearing.caseNumber order by dateOfEntry desc";
	$result = mysql_query($sql,$link);
	if(!$result)
	{
		print "Error getting data from the system. ".mysql_error()."<br>";
	}
	else
	{
		$returned = mysql_num_rows($result);
		if($returned==0)
		{
			print "There are 0 entries in the database.";
		}
		else
		{
			$x = 1;
			print "<table width=950px border=1px>";
			print "<thead><th>#</th><th align='right'>CASE No.</th><th align='left'>OFFENCE</th><th align='left'>STATION</th><th align='left'>PLAINTIFF</th><th align='right'>ID No.</th><th align='left'>EMAIL</th><th>CHAT</th><th align='right'>JUDGE No.</th><th align='left'>VERDICT</th><th align='right'>FINE</th><th align='right'>PAY</th></thead>";
			while($row=mysql_fetch_array($result))
			{
				if($x%2==0)
				{
					$class = 'even';
				}
				else
				{
					$class = 'odd';
				}
				print "<tr class='".$class."'><td align='right'>".$x."</td><td align='right'>".$row[caseNumber]."</td><td align='left'>".$row[offence]."</td><td align='left'>";
				print $row[policeStation];
				print "</td><td align='left'>";
				print $row[names];
				print "</td><td align='right'>".$row[national_id];
				print '';
				print "</td><td align='left'>";
				print $row[email];
				print "</td><td align='center'><a href='skype:USERNAME?chat'><img src='images/skype.png' width=20px height=20px></a></td><td align='right'>".$row[judgeNo]."</td><td align='left'>";
					print $row[caseVerdict];
					$theFine = $row[fine];
				print "</td><td align='right'>".number_format(floatval($row[fine]))."</td><td align='center'>";
				$caseNo = $row[caseNumber];
				$sql_2 = "select * from fine where case_no='".$caseNo."'"; // This is to check if there has been payment for the fine in this case...
				$result_2 = mysql_query($sql_2,$link);
				if(!$result_2)
				{
					print "<div id='alertBox'>Error reading fines from the system. ".mysql_error()."</div>";
				}
				else
				{
					$returnedRows = mysql_num_rows($result_2);
					if($returnedRows==0)
					{
						print "<a href='paynew.php?cno=".$row[caseNumber]."&&fne=".$theFine."'><img src='images/cash_icon.png' align='absbottom' title='not paid' width=22px height=19px></a>";
					}
					else
					{
						print "<img src='images/Check.png' align='' title='fully paid' width=18px height=15px>";
					}
				}
				print "</td></tr>";
				$x++;
			}
			print "</table><hr>";
		}
	}

	include('footer.php');
?>
 
</body>
</html>