/*
Navicat MySQL Data Transfer

Source Server         : D_Folt
Source Server Version : 50539
Source Host           : localhost:3306
Source Database       : ecourt

Target Server Type    : MYSQL
Target Server Version : 50539
File Encoding         : 65001

Date: 2019-04-01 17:34:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for casedetails
-- ----------------------------
DROP TABLE IF EXISTS `casedetails`;
CREATE TABLE `casedetails` (
  `hearingID` varchar(50) NOT NULL,
  `caseNumber` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `defendant_ID` varchar(50) DEFAULT NULL,
  `time` time NOT NULL,
  `policeStation` varchar(50) NOT NULL,
  `policeID` varchar(50) DEFAULT NULL,
  `entryOfficer` text NOT NULL,
  PRIMARY KEY (`hearingID`),
  UNIQUE KEY `caseNumber` (`caseNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of casedetails
-- ----------------------------

-- ----------------------------
-- Table structure for casse
-- ----------------------------
DROP TABLE IF EXISTS `casse`;
CREATE TABLE `casse` (
  `caseNumber` varchar(50) NOT NULL,
  `policeStation` varchar(50) NOT NULL,
  `policeID` int(30) DEFAULT NULL,
  `nationalID` varchar(50) NOT NULL,
  `offence` varchar(50) NOT NULL,
  `email` text NOT NULL,
  `cellphone` text NOT NULL,
  `gender` text NOT NULL,
  `names` text NOT NULL,
  `timeOfEntry` datetime NOT NULL,
  `entryOfficer` text NOT NULL,
  PRIMARY KEY (`caseNumber`),
  UNIQUE KEY `nationalID` (`nationalID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of casse
-- ----------------------------
INSERT INTO `casse` VALUES ('LTZ120', 'Muthangari', '0', '10010002', 'Arson', 'w.kamau@hotmail.com', '+254720123124', 'm', 'John Walker', '2019-03-13 17:49:28', 'Phillip Otieno');
INSERT INTO `casse` VALUES ('LTZ121', 'Githurai', '0', '10010004', 'Public disturbance', 'faith.kimani@hotmail.com', '+254720123123', 'f', 'Faith Kimani', '2019-03-13 17:51:14', 'Phillip Otieno');
INSERT INTO `casse` VALUES ('LTZ123', 'Kabete', '0', '10010003', 'Drunken driving', 'ahmed1988@outlook.com', '+254720123121', 'm', 'Ahmed Hussein', '2019-03-13 17:53:43', 'Phillip Otieno');
INSERT INTO `casse` VALUES ('LTZ124', 'Muthaiga', '0', '22334456', 'Carjacking', 'james.bond@gmail.com', '+254720123124', 'm', 'James Bond', '2019-03-13 16:29:00', 'Phillip Otieno');
INSERT INTO `casse` VALUES ('LTZ130', 'Kitengela', '0', '88999323', 'Public Nuisance', 'c.musyoki@hotmail.com', '+254720123124', 'm', 'Charles Musyoki', '2019-04-01 16:42:08', 'Phillip Otieno');

-- ----------------------------
-- Table structure for courthearing
-- ----------------------------
DROP TABLE IF EXISTS `courthearing`;
CREATE TABLE `courthearing` (
  `caseNumber` varchar(50) NOT NULL,
  `judgeNo` varchar(50) NOT NULL,
  `nationalID` varchar(10) NOT NULL,
  `caseTime` datetime NOT NULL,
  `prosecutorNo` varchar(50) NOT NULL,
  `caseVerdict` varchar(100) DEFAULT NULL,
  `hearingID` varchar(10) NOT NULL,
  `fine` varchar(50) NOT NULL,
  `attachment` text NOT NULL,
  `videolink` text NOT NULL,
  `dateOfEntry` datetime NOT NULL,
  `entryOfficer` text NOT NULL,
  PRIMARY KEY (`caseNumber`),
  UNIQUE KEY `nationalID` (`nationalID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of courthearing
-- ----------------------------
INSERT INTO `courthearing` VALUES ('LTZ120', '7', '10010002', '2019-03-25 17:10:00', '3', 'DISMISSED', '', '0', 'casefiles/cash-receipt-form.pdf', '#', '2019-03-13 17:49:28', 'Phillip Otieno');
INSERT INTO `courthearing` VALUES ('LTZ121', '7', '10010004', '2019-04-02 09:30:00', '8', null, '', '', '', '', '2019-03-13 17:51:14', 'Phillip Otieno');
INSERT INTO `courthearing` VALUES ('LTZ123', '2', '10010003', '2019-04-01 16:12:00', '3', 'GUILTY', '', '15000', '', 'videos/case001.mp4', '2019-03-13 17:53:43', 'Phillip Otieno');
INSERT INTO `courthearing` VALUES ('LTZ124', '2', '22334456', '2019-03-21 08:13:00', '8', 'GUILTY', '', '2500', 'casefiles/844__New_Syllabus.pdf', '', '2019-03-13 16:29:00', 'Phillip Otieno');
INSERT INTO `courthearing` VALUES ('LTZ130', '', '88999323', '0000-00-00 00:00:00', '', null, '', '', '', '', '2019-04-01 16:42:08', 'Phillip Otieno');

-- ----------------------------
-- Table structure for fine
-- ----------------------------
DROP TABLE IF EXISTS `fine`;
CREATE TABLE `fine` (
  `fullName` varchar(40) NOT NULL,
  `card_Type` varchar(30) NOT NULL,
  `national_id` varchar(10) NOT NULL,
  `card_number` varchar(16) NOT NULL,
  `acc_number` varchar(15) NOT NULL,
  `case_no` varchar(20) NOT NULL,
  `bank` varchar(30) NOT NULL,
  `cvs` int(4) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`acc_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of fine
-- ----------------------------
INSERT INTO `fine` VALUES ('Morris Okello', 'MC', '', '1263126312631263', '', '', 'Barclays bank of Kenya', '1122', '0000-00-00 00:00:00');
INSERT INTO `fine` VALUES ('Jim Kelly', 'MC', '22334456', '346576879353', '1619889912', 'LTZ124', 'Commercial Bank of Africa', '1124', '2019-03-20 17:33:46');
INSERT INTO `fine` VALUES ('Bill Gates', 'V', '23123456', '346576879353', '34567345678', 'LTZ245', 'KCB', '1345', '2019-03-20 16:36:35');

-- ----------------------------
-- Table structure for payments
-- ----------------------------
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `payment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `amountPaid` bigint(20) DEFAULT NULL,
  `balance` bigint(20) DEFAULT NULL,
  `caseNumber` text,
  `dateOfPayment` date DEFAULT NULL,
  `entryOfficer` text,
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of payments
-- ----------------------------
INSERT INTO `payments` VALUES ('4', '2500', '0', 'LTZ124', '2019-03-20', 'Phillip Otieno');

-- ----------------------------
-- Table structure for person
-- ----------------------------
DROP TABLE IF EXISTS `person`;
CREATE TABLE `person` (
  `nationalID` varchar(10) NOT NULL,
  `fName` varchar(50) NOT NULL,
  `lName` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `offence` varchar(100) NOT NULL,
  `caseNumber` varchar(50) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `policeStation` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `entryOfficer` text NOT NULL,
  PRIMARY KEY (`nationalID`),
  UNIQUE KEY `caseNumber` (`caseNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of person
-- ----------------------------
INSERT INTO `person` VALUES ('33280296', 'kim', 'mati', 'a1', 'trespassing', 'A124FER', 'a@gmail.com', 'Ruiru', 'criminal', '');

-- ----------------------------
-- Table structure for police_station
-- ----------------------------
DROP TABLE IF EXISTS `police_station`;
CREATE TABLE `police_station` (
  `stationID` varchar(50) NOT NULL,
  `police_fname` varchar(50) NOT NULL,
  `police_lname` varchar(50) NOT NULL,
  `policeStation` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nationalID` varchar(10) NOT NULL,
  `entryOfficer` text NOT NULL,
  PRIMARY KEY (`stationID`),
  UNIQUE KEY `nationalID` (`nationalID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of police_station
-- ----------------------------

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `userId` bigint(20) NOT NULL AUTO_INCREMENT,
  `fullname` text NOT NULL,
  `national_id` bigint(20) DEFAULT NULL,
  `gender` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `rights` text NOT NULL,
  `email` text NOT NULL,
  `mobile_number` text NOT NULL,
  `entryOfficer` text NOT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'Don Ochieng\'', '13288899', '', 'don', '*804424B6DD59417627E949DBF18C32D7D08A86C7', 'POL', 'donochi@gmail.com', '+254720231104', '');
INSERT INTO `users` VALUES ('2', 'Steve Muema', '97899879', 'm', 'steve', '*D95CCB971C6834A1500A36AB765D187226A7818C', 'JUD', 'steve.muema@gmail.com', '+254735200458', '');
INSERT INTO `users` VALUES ('3', 'John Akombe', '12377690', 'm', 'jakombe', '*DACDE7F5744D3CB439B40D938673B8240B824853', 'PRO', 'akombej@yahoo.co.uk', '+254713675890', '');
INSERT INTO `users` VALUES ('4', 'Phillip Otieno', '12344321', 'm', 'phillip', '*C203B2C53722D75171B711DCAFA1CE6F23D6F590', 'ADM', 'p.otieno@yahoo.com', '+254735200458', '');
INSERT INTO `users` VALUES ('5', 'Susan Mwangi', '12344324', 'f', 'susan', '*C391980232FA468D6B1C82BC2A6D4DEB18AF4D21', 'CRI', 's.mwangi@gmail.com', '+254735200458', '');
INSERT INTO `users` VALUES ('6', 'Lucy Achieng', '22334455', 'f', 'lucy', '*CB89BB054D1BED69BF24CA582FADEEBBBAD132CC', 'CRI', 'a.lucy@hotmail.com', '+254712345678', '');
INSERT INTO `users` VALUES ('7', 'Maureen Kamau', '88833322', 'f', 'maureen', '*97C7EB10754693404CE79A2197FAA60690FC4FAC', 'JUD', 'm.kamau@hotmail.com', '+254722123123', '');
INSERT INTO `users` VALUES ('8', 'Valery Otieno', '22334459', 'f', 'val', '*39DD4D84B22AF56D28450F170EB0303A5E5FA63F', 'PRO', 'val.oti@outlook.com', '+254735200459', '');
