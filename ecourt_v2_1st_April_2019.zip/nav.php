<a class="navBox" align='left' href='index.php'>HOME</a> <a class="navBox" align='left' href='filing.php'>CASE FILING</a> <a class="navBox" align='left' href='hearingdetails.php'>HEARING DETAILS</a> <a class="navBox" align='left' href='trackingform.php'>TRACK CASE</a> <a class="navBox" align='left' href='casepage.php'>CASE</a> 
<?php
	// global $session;
	if($_SESSION[session])
	{
		$thisSession= $_SESSION[session];
		$theName = $thisSession[thisUser];
		$rights = $thisSession[userRights];
		print '<b><i> welcome '.$theName.'</i></b> <a class="navBox" align="left" href="logout.php">LOGOUT</a>';
	}
	else
	{
		print '<a class="navBox" align="left" href="login.php">Log In</a>';
	}
?>
