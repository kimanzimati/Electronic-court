-- phpMyAdmin SQL Dump
-- version 4.7.8
-- https://www.phpmyadmin.net/
--
-- Host: 10.123.0.59:3307
-- Generation Time: Mar 07, 2019 at 05:47 AM
-- Server version: 5.7.23
-- PHP Version: 7.0.33-0+deb9u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecourt`
--

-- --------------------------------------------------------

--
-- Table structure for table `casedetails`
--

CREATE TABLE `casedetails` (
  `hearingID` varchar(50) NOT NULL,
  `caseNumber` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `defendant_ID` varchar(50) DEFAULT NULL,
  `time` time NOT NULL,
  `policeStation` varchar(50) NOT NULL,
  `policeID` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `casse`
--

CREATE TABLE `casse` (
  `caseNumber` varchar(50) NOT NULL,
  `policeStation` varchar(50) NOT NULL,
  `policeID` int(30) DEFAULT NULL,
  `nationalID` varchar(50) NOT NULL,
  `offence` varchar(50) NOT NULL,
  `email` text NOT NULL,
  `gender` text NOT NULL,
  `names` text NOT NULL,
  `timeOfEntry` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `casse`
--

INSERT INTO `casse` (`caseNumber`, `policeStation`, `policeID`, `nationalID`, `offence`, `email`, `gender`, `names`, `timeOfEntry`) VALUES
('1001001', 'Kitale', 0, '007', 'DUI', 'james.bond@gmail.com', 'm', 'James Bond', '0000-00-00 00:00:00'),
('1001001RTS', 'Kabete', 0, '00790', 'Loitering', 'j.chan@hotmail.com', 'm', 'Jacky Chan', '0000-00-00 00:00:00'),
('2001001RTS', 'Muthaiga', 0, '070087335', 'DUI', 'titus.omondi@hotmail.com', 'm', 'Titus Omondi', '2019-03-01 16:38:48'),
('AAR100123', 'Westlands', 0, '9879979', 'Carjacking', 'lucy.wangui@gmail.com', 'f', 'Lucy Wangui', '0000-00-00 00:00:00'),
('AAR100124', 'Kitisuru', 0, '070087332', 'Pick-pocketing', 'm.kiunjuri@excite.com', 'm', 'Mwangi Kiunjuri', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `courthearing`
--

CREATE TABLE `courthearing` (
  `caseNumber` varchar(50) NOT NULL,
  `judgeNo` varchar(50) NOT NULL,
  `nationalID` varchar(10) NOT NULL,
  `caseTime` time NOT NULL,
  `prosecutorNo` varchar(50) NOT NULL,
  `caseVerdict` varchar(100) DEFAULT NULL,
  `hearingID` varchar(10) NOT NULL,
  `fine` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courthearing`
--

INSERT INTO `courthearing` (`caseNumber`, `judgeNo`, `nationalID`, `caseTime`, `prosecutorNo`, `caseVerdict`, `hearingID`, `fine`) VALUES
('A978797999', 'A321', '23257278', '15:30:00', 'P001', NULL, 'AK001', ''),
('A987989890', 'A123', '12345678', '15:45:00', 'P001', NULL, 'AK002', ''),
('BZ9988998', 'A321', '33280296', '16:00:00', 'P002', NULL, 'AK003', ''),
('RTF20330', 'BK021', '99887766', '16:20:00', 'P003', NULL, 'AZ003', '');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `nationalID` varchar(10) NOT NULL,
  `fName` varchar(50) NOT NULL,
  `lName` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `offence` varchar(100) NOT NULL,
  `caseNumber` varchar(50) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `policeStation` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`nationalID`, `fName`, `lName`, `password`, `offence`, `caseNumber`, `email`, `policeStation`, `status`) VALUES
('33280296', 'kim', 'mati', 'a1', 'trespassing', 'A124FER', 'a@gmail.com', 'Ruiru', 'criminal');

-- --------------------------------------------------------

--
-- Table structure for table `police_station`
--

CREATE TABLE `police_station` (
  `stationID` varchar(50) NOT NULL,
  `police_fname` varchar(50) NOT NULL,
  `police_lname` varchar(50) NOT NULL,
  `policeStation` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nationalID` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` bigint(20) NOT NULL,
  `fullname` text NOT NULL,
  `national_id` bigint(20) DEFAULT NULL,
  `gender` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `rights` text NOT NULL,
  `email` text NOT NULL,
  `mobile_number` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `fullname`, `national_id`, `gender`, `username`, `password`, `rights`, `email`, `mobile_number`) VALUES
(1, 'Don Ochieng\'', 13288899, '', 'don', '*804424B6DD59417627E949DBF18C32D7D08A86C7', 'AA', 'donochi@gmail.com', '+254720231104'),
(2, 'Steve Muema', 97899879, 'm', 'steve', '*D95CCB971C6834A1500A36AB765D187226A7818C', 'JUD', 'steve.muema@gmail.com', '+254735200458'),
(3, 'John Akombe', 12377690, 'm', 'jakombe', '*EF99045F4FD5F8742BA4139CB1117C74DAAB1735', 'JUD', 'akombej@yahoo.co.uk', '+254713675890');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `casedetails`
--
ALTER TABLE `casedetails`
  ADD PRIMARY KEY (`hearingID`),
  ADD UNIQUE KEY `caseNumber` (`caseNumber`);

--
-- Indexes for table `casse`
--
ALTER TABLE `casse`
  ADD PRIMARY KEY (`caseNumber`),
  ADD UNIQUE KEY `nationalID` (`nationalID`);

--
-- Indexes for table `courthearing`
--
ALTER TABLE `courthearing`
  ADD PRIMARY KEY (`caseNumber`),
  ADD UNIQUE KEY `nationalID` (`nationalID`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`nationalID`),
  ADD UNIQUE KEY `caseNumber` (`caseNumber`);

--
-- Indexes for table `police_station`
--
ALTER TABLE `police_station`
  ADD PRIMARY KEY (`stationID`),
  ADD UNIQUE KEY `nationalID` (`nationalID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
