<!DOCTYPE HTML>
<?php
	include('connect.php');
	checkCriminal(); // This line only checks if the user is a criminal with rights, if not they are knocked off the page...
	
	if(isset($_POST[action])&&$_POST[action]=='addUser')
	{
		if($_GET[cno])
		{
			$caseNumber = $_GET[cno];
			$theFine = $_GET[fne];
		}
		if($_SESSION[session])
		{
			$thisSession = $_SESSION[session];
			$thisUser = $thisSession[thisUser];
		}
		global $link;
		$fullNames = $_POST[fullName];
		$cardType = $_POST[card_Type];
		$nationalID=$_POST[nationalID];
		$cardNumber = $_POST[card_number];
		$accountNumber = $_POST[accountnumber];
		$caseNumber = $_POST[case_number];
		$bank = $_POST[bank];
		$cvs = $_POST[cvs];
		
		$sql = "insert into fine(fullname,card_Type,national_id,card_number,acc_number,case_no,bank,cvs,date) value('$fullNames','$cardType','$nationalID','$cardNumber','$accountNumber','$caseNumber','$bank','$cvs',NOW())";
		$sql2 = "insert into payments(amountPaid,balance,caseNumber,dateOfPayment,entryOfficer) value('$theFine',0,'$caseNumber',CURDATE(),'$thisUser')";
		$result = mysql_query($sql,$link);
		$result2 = mysql_query($sql2,$link);
		if(!$result)
		{
			print "Error adding fine details to the system. ".mysql_error();
		}
		if(!$result2)
		{
			print "Error adding payment details to the system. ".mysql_error();
		}
		else
		{
			print "<h1>New payment data added successfully</h1>";
		}
	}
	
?>

<html>
<head>
  <title>Fine Payment Form</title>
	<link rel='stylesheet' type='text/css' href='stylez.css'>
</head>
<body background="images/background002.jpg">
<hr>
<?php
	include('nav.php');
	if($_GET[cno])
	{
		$caseNumber = $_GET[cno];
		$theFine = $_GET[fne];
	}
?>
<hr>
 <form method="POST">
	<input type='hidden' name='action' value='addUser'>
	<input type='hidden' name='case_number' value='<?php print $caseNumber;?>'>
  <table>
   <tr>
    <td>Full Names :</td>
    <td><input type="text" name="fullName" required></td>
   </tr>
   <tr>
    <td>Card Type :</td>
    <td>
		<select name='card_Type'>
			<option selected disabled>Card Type</option>
			<option value='MC'>MasterCard</option>
			<option value='V'>Visa</option>
			<option value='AE'>American Express</option>
			
		</select>
	</td>
   </tr>
   <tr>
    <td>National ID :</td>
    <td><input type="text" name="nationalID" required></td>
   </tr>
   
   <tr>
    <td>Account Number :</td>
    <td><input type="text" name="accountnumber" required></td>
   </tr>
      <tr>
    <td>Case Number :</td>
    <td><input type="text" name="card_number" required></td>
   </tr>
   <tr>
    <td>Bank :</td>
    <td><input type="text" name="bank" required></td>
   </tr> 
   <tr>
    <td>CVS :</td>
    <td>
     <input type="text" name="cvs" required>
    </td>
   </tr>
   <tr>
    <td><input class='submitBox' type="submit" value="Submit"></td>
   </tr>
  </table>
 </form>
<?php
	include('footer.php');
?>
</body>
</html>