<!DOCTYPE HTML>
<?php
	include('connect.php');
	checkPoliceOfficer(); // This line only checks if the user is a police officer, if yes then they are knocked off the page...
	
	if(isset($_POST[action])&&$_POST[action]=='addTrackingDetails')
	{
		global $link;
		$national_id = addslashes($_POST[nationalID]);
		$case_number = addslashes($_POST[caseNumber]);
		$case_time = addslashes($_POST[caseTime]);
		$judge_number = addslashes($_POST[judgeNumber]);
		$prosecutor_number = addslashes($_POST[prosecutorNumber]);
		
		
		$sql = "insert into courthearing(caseNumber,nationalID,judgeNo,prosecutorNo,caseTime,dateOfEntry) value('$case_number','$national_id','$judge_number','$prosecutor_number','$case_time',CURDATE())";
		$result = mysql_query($sql,$link);
		if(!$result)
		{
			print "Error adding details to the system. ".mysql_error();
		}
		else
		{
			print "<h1>Data added successfully</h1>";
		}
	}
	
?>
<html>
<head>
	<title>Tracking Form</title>
	<link rel='stylesheet' type='text/css' href='stylez.css'>
</head>
<body  background="images/background002.jpg">
      <hr>
      <?php
      	include('nav.php');
      ?>  
      <hr>
<?php
	global $link;
	$sql = "select * from courthearing order by dateOfEntry desc";
	$result = mysql_query($sql,$link);
	if(!$result)
	{
		print "Error getting data from the system. ".mysql_error()."<br>";
	}
	else
	{
		$returned = mysql_num_rows($result);
		if($returned==0)
		{
			print "There are 0 entries in the database.";
		}
		else
		{
			$x = 1;
			print "<table width=900px border=1px>";
			print "<thead><th>#</th><th align='left'>CASE</th><th align='right'>JUDGE</th><th align='right'>PROSECUTOR</th><th>ID NO. </th><th>VERDICT</th><th>FINE (KES)</th><th>DOCUMENT</th><th>CASE DATE</th></thead>";
			while($row=mysql_fetch_array($result))
			{
				if($x%2==0)
				{
					$class = 'even';
				}
				else
				{
					$class = 'odd';
				}
				print "<tr class='".$class."'><td align='right'>".$x."</td><td align='left'>".$row[caseNumber]."</td><td align='right'>";
				$theJudge = $row[judgeNo];
				$caseNo = $row[caseNumber];
				if(!$theJudge)
				{
					print "<center><a href='adminfillform.php?ref=".$caseNo."'><img title='assign officials' align='absbottom' src='images/tool.png'></a></center>";
				}
				else
				{
					print $row[judgeNo];
				}
				print "</td><td align='right'>";
				if(!$row[prosecutorNo])
				{
					print "<center><a href='adminfillform.php?ref=".$caseNo."'><img title='assign officials' align='absbottom' src='images/tool.png'></a></center>";
				}
				else
				{
					print $row[prosecutorNo];
				}
				print "</td><td align='right'>".$row[nationalID]."</td><td align='right'>";
				$theVerdict = $row[caseVerdict];
				if($theVerdict!='GUILTY'&&$theVerdict!='DISMISSED')
				{
					$caseNo = $row[caseNumber];
					$thisSession = $_SESSION[session];
					$rights = $thisSession[userRights];
					if($rights=='JUD')
					{
						print "<a href='judgefillform.php?number=".$caseNo."'>PENDING</a>";
					}
				}
				else
				{
					print $theVerdict;
				}
				$theFine =floatval($row[fine]);
				print "</td><td align='right'>".number_format($theFine)." ";
				
				$sql_a = "select sum(amountPaid) as totalPaid from payments where caseNumber='$caseNo'";
				$result_a = mysql_query($sql_a,$link);
				if(!$result_a)
				{
					print "<div id='alertBox'>Error reading fine payments from the system. ".mysql_error()."</div>";
				}
				else
				{
					while($row_a=mysql_fetch_array($result_a))
					{
						$totalPayments =  $row_a[totalPaid];
						$balance = $totalPayments - $theFine;
					}
				}
				if($balance<0&&$theFine!=0)
				{
					print "| <img src='images/Delete.png' title='Fine has not been paid' align='' width=12px height=12px>";
				}
				else
				if($balance>=0&&$theFine!=0)
				{
					print "| <img src='images/Check.png' title='Fine has been paid' align='' width=12px height=12px>";					
				}
				print "</td><td align='center'><a target='_blank' href='".$row[attachment]."'>";
				$theAttachment = $row[attachment];
				if($theAttachment)
				{
					print "<img src='images/Folder.png' align='absbottom' height=16px width=19px title='case file'>";
				}
				print "</a> | <a href='".$row[videolink]."' target='_blank'><img src='images/Movie.png' height=16px width=16px align='absbottom'></a></td><td align='right'>".$row[caseTime]."</td></tr>";
				$x++;
			}
			print "</table><hr>";
		}
	}
?>
<?php
	include('footer.php');
?>
 
</body>
</html>