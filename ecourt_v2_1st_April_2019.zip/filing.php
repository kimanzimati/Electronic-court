<!DOCTYPE HTML>
<?php
	include('connect.php');

	checkProsecutor(); // this line and the next one ensures Prosecutors are not allowed to view this page
	checkJudge(); // this line and the next one ensures Prosecutors are not allowed to view this page
	checkCriminal(); // this line and the next one ensures Accused persons are not allowed to view this page
	// only administrators and police officers are allowed to access this page...
	if(isset($_POST[action])&&$_POST[action]=='addCaseDetails')
	{
		$thisSession = $_SESSION[session];
		$thisUser = $thisSession[thisUser];
		global $link;
		$names = $_POST[name];
		$mobileNumber = $_POST[cellphoneNumber];
		$national_id = $_POST[nationalID];
		$case_number = $_POST[caseNumber];
		$station = $_POST[policeStation];
		$gender = $_POST[gender];
		$email = $_POST[email];
		$offens = $_POST[offence];
		$police_id = $_POST[policeID];
		
		$sql = "insert into casse(names,caseNumber,policeStation,policeID,nationalID,offence,email,gender,timeOfEntry,entryOfficer,cellphone) value('$names','$case_number','$station','$police_id','$national_id','$offens','$email','$gender',NOW(),'$thisUser','$mobileNumber')";
		$result = mysql_query($sql,$link);

		$sql2 = "insert into courthearing(caseNumber,nationalID,entryOfficer,dateOfEntry) values('$case_number','$national_id','$thisUser',NOW())";
		$result2 = mysql_query($sql2,$link);

		if(!$result)
		{
			print "Error adding details to the system. ".mysql_error();
		}
		else
		if(!$result2)
		{
			print "Error adding details 2 to the system. ".mysql_error();
		}
		else
		{
			print "<h1>Data added successfully</h1>";
		}
	}
	
?>
<html>
<head>
  <title>Filing Form</title>
<link rel='stylesheet' type='text/css' href='stylez.css'>
</head>
<body background="images/background002.jpg">
<hr>
<?php
	include('nav.php');
?>
<hr>
 <form method="POST">
 <table>
 <fieldset>
 <legend> Case Filing Form </legend>
	<input type='hidden' name='action' value='addCaseDetails'>
	<div id='row'><div id='label'>Full Names :</div><input id='f_input' type="text" name="name" required></div>
	<div id='row'><div id='label'>National ID :</div><input id='f_input' type="text" name="nationalID" required></div>
	<div id='row'><div id='label'>Case number :</div><input id='f_input' type="text" name="caseNumber" required></div>
	<div id='row'><div id='label'>Offence :</div><input id='f_input' type="text" name="offence" required></div>
	<div id='row'><div id='label'>Police ID :</div><input id='f_input' type="text" name="policeID" required></div>
	<div id='row'><div id='label'>Police Station :</div><input id='f_input' type="text" name="policeStation" required></div>
	<div id='row'><div id='label'>Cellphone :</div><input id='f_input' type="text" name="cellphoneNumber" required></div>

	<div id='row'><div id='label'>Gender :</div>
	<select name='gender' id='f_input'>
		<option value='f'>Female</option>
		<option value='m'>Male</option>
	</select>
	</div>
	<div id='row'><div id='label'>Email :</div><input id='f_input' type="email" name="email" required></div>
	<div id='row'><div id='label'><input class='' type="submit" value="submit"></div></div>
</fieldset>

   </table>
</form>
<?php
	include('footer.php');
?>
 </body>
</html>