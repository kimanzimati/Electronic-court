-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2019 at 03:36 PM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dconsort_ecourt`
--

-- --------------------------------------------------------

--
-- Table structure for table `casedetails`
--

CREATE TABLE IF NOT EXISTS `casedetails` (
  `hearingID` varchar(50) NOT NULL,
  `caseNumber` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `defendant_ID` varchar(50) DEFAULT NULL,
  `time` time NOT NULL,
  `policeStation` varchar(50) NOT NULL,
  `policeID` varchar(50) DEFAULT NULL,
  `entryOfficer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `casse`
--

CREATE TABLE IF NOT EXISTS `casse` (
  `caseNumber` varchar(50) NOT NULL,
  `policeStation` varchar(50) NOT NULL,
  `policeID` int(30) DEFAULT NULL,
  `nationalID` varchar(50) NOT NULL,
  `offence` varchar(50) NOT NULL,
  `email` text NOT NULL,
  `cellphone` text NOT NULL,
  `gender` text NOT NULL,
  `names` text NOT NULL,
  `timeOfEntry` datetime NOT NULL,
  `entryOfficer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `casse`
--

INSERT INTO `casse` (`caseNumber`, `policeStation`, `policeID`, `nationalID`, `offence`, `email`, `cellphone`, `gender`, `names`, `timeOfEntry`, `entryOfficer`) VALUES
('LTZ120', 'Muthangari', 0, '10010002', 'Arson', 'w.kamau@hotmail.com', '+254720123124', 'm', 'John Walker', '2019-03-13 17:49:28', 'Phillip Otieno'),
('LTZ121', 'Githurai', 0, '10010004', 'Public disturbance', 'faith.kimani@hotmail.com', '+254720123123', 'f', 'Faith Kimani', '2019-03-13 17:51:14', 'Phillip Otieno'),
('LTZ123', 'Kabete', 0, '10010003', 'Drunken driving', 'ahmed1988@outlook.com', '+254720123121', 'm', 'Ahmed Hussein', '2019-03-13 17:53:43', 'Phillip Otieno'),
('LTZ124', 'Muthaiga', 0, '22334456', 'Carjacking', 'james.bond@gmail.com', '+254720123124', 'm', 'James Bond', '2019-03-13 16:29:00', 'Phillip Otieno');

-- --------------------------------------------------------

--
-- Table structure for table `courthearing`
--

CREATE TABLE IF NOT EXISTS `courthearing` (
  `caseNumber` varchar(50) NOT NULL,
  `judgeNo` varchar(50) NOT NULL,
  `nationalID` varchar(10) NOT NULL,
  `caseTime` time NOT NULL,
  `prosecutorNo` varchar(50) NOT NULL,
  `caseVerdict` varchar(100) DEFAULT NULL,
  `hearingID` varchar(10) NOT NULL,
  `fine` varchar(50) NOT NULL,
  `attachment` text NOT NULL,
  `videolink` text NOT NULL,
  `dateOfEntry` datetime NOT NULL,
  `entryOfficer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courthearing`
--

INSERT INTO `courthearing` (`caseNumber`, `judgeNo`, `nationalID`, `caseTime`, `prosecutorNo`, `caseVerdict`, `hearingID`, `fine`, `attachment`, `videolink`, `dateOfEntry`, `entryOfficer`) VALUES
('LTZ120', '7', '10010002', '00:00:00', '3', 'DISMISSED', '', '0', 'casefiles/cash-receipt-form.pdf', '#', '2019-03-13 17:49:28', 'Phillip Otieno'),
('LTZ121', '', '10010004', '00:00:00', '', NULL, '', '', '', '', '2019-03-13 17:51:14', 'Phillip Otieno'),
('LTZ123', '', '10010003', '00:00:00', '', NULL, '', '', '', '', '2019-03-13 17:53:43', 'Phillip Otieno'),
('LTZ124', '2', '22334456', '00:00:00', '8', 'GUILTY', '', '2500', 'casefiles/844__New_Syllabus.pdf', '', '2019-03-13 16:29:00', 'Phillip Otieno');

-- --------------------------------------------------------

--
-- Table structure for table `fine`
--

CREATE TABLE IF NOT EXISTS `fine` (
  `fullName` varchar(40) NOT NULL,
  `card_Type` varchar(30) NOT NULL,
  `national_id` varchar(10) NOT NULL,
  `card_number` varchar(16) NOT NULL,
  `acc_number` varchar(15) NOT NULL,
  `case_no` varchar(20) NOT NULL,
  `bank` varchar(30) NOT NULL,
  `cvs` int(4) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fine`
--

INSERT INTO `fine` (`fullName`, `card_Type`, `national_id`, `card_number`, `acc_number`, `case_no`, `bank`, `cvs`, `date`) VALUES
('Morris Okello', 'MC', '', '1263126312631263', '', '', 'Barclays bank of Kenya', 1122, '0000-00-00 00:00:00'),
('Jim Kelly', 'MC', '22334456', '346576879353', '1619889912', 'LTZ124', 'Commercial Bank of Africa', 1124, '2019-03-20 17:33:46'),
('Bill Gates', 'V', '23123456', '346576879353', '34567345678', 'LTZ245', 'KCB', 1345, '2019-03-20 16:36:35');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
`payment_id` bigint(20) NOT NULL,
  `amountPaid` bigint(20) DEFAULT NULL,
  `balance` bigint(20) DEFAULT NULL,
  `caseNumber` text,
  `dateOfPayment` date DEFAULT NULL,
  `entryOfficer` text
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `amountPaid`, `balance`, `caseNumber`, `dateOfPayment`, `entryOfficer`) VALUES
(4, 2500, 0, 'LTZ124', '2019-03-20', 'Phillip Otieno');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE IF NOT EXISTS `person` (
  `nationalID` varchar(10) NOT NULL,
  `fName` varchar(50) NOT NULL,
  `lName` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `offence` varchar(100) NOT NULL,
  `caseNumber` varchar(50) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `policeStation` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `entryOfficer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`nationalID`, `fName`, `lName`, `password`, `offence`, `caseNumber`, `email`, `policeStation`, `status`, `entryOfficer`) VALUES
('33280296', 'kim', 'mati', 'a1', 'trespassing', 'A124FER', 'a@gmail.com', 'Ruiru', 'criminal', '');

-- --------------------------------------------------------

--
-- Table structure for table `police_station`
--

CREATE TABLE IF NOT EXISTS `police_station` (
  `stationID` varchar(50) NOT NULL,
  `police_fname` varchar(50) NOT NULL,
  `police_lname` varchar(50) NOT NULL,
  `policeStation` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nationalID` varchar(10) NOT NULL,
  `entryOfficer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`userId` bigint(20) NOT NULL,
  `fullname` text NOT NULL,
  `national_id` bigint(20) DEFAULT NULL,
  `gender` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `rights` text NOT NULL,
  `email` text NOT NULL,
  `mobile_number` text NOT NULL,
  `entryOfficer` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `fullname`, `national_id`, `gender`, `username`, `password`, `rights`, `email`, `mobile_number`, `entryOfficer`) VALUES
(1, 'Don Ochieng''', 13288899, '', 'don', '*804424B6DD59417627E949DBF18C32D7D08A86C7', 'POL', 'donochi@gmail.com', '+254720231104', ''),
(2, 'Steve Muema', 97899879, 'm', 'steve', '*D95CCB971C6834A1500A36AB765D187226A7818C', 'JUD', 'steve.muema@gmail.com', '+254735200458', ''),
(3, 'John Akombe', 12377690, 'm', 'jakombe', '*DACDE7F5744D3CB439B40D938673B8240B824853', 'PRO', 'akombej@yahoo.co.uk', '+254713675890', ''),
(4, 'Phillip Otieno', 12344321, 'm', 'phillip', '*C203B2C53722D75171B711DCAFA1CE6F23D6F590', 'ADM', 'p.otieno@yahoo.com', '+254735200458', ''),
(5, 'Susan Mwangi', 12344324, 'f', 'susan', '*C391980232FA468D6B1C82BC2A6D4DEB18AF4D21', 'CRI', 's.mwangi@gmail.com', '+254735200458', ''),
(6, 'Lucy Achieng', 22334455, 'f', 'lucy', '*CB89BB054D1BED69BF24CA582FADEEBBBAD132CC', 'CRI', 'a.lucy@hotmail.com', '+254712345678', ''),
(7, 'Maureen Kamau', 88833322, 'f', 'maureen', '*97C7EB10754693404CE79A2197FAA60690FC4FAC', 'JUD', 'm.kamau@hotmail.com', '+254722123123', ''),
(8, 'Valery Otieno', 22334459, 'f', 'val', '*39DD4D84B22AF56D28450F170EB0303A5E5FA63F', 'PRO', 'val.oti@outlook.com', '+254735200459', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `casedetails`
--
ALTER TABLE `casedetails`
 ADD PRIMARY KEY (`hearingID`), ADD UNIQUE KEY `caseNumber` (`caseNumber`);

--
-- Indexes for table `casse`
--
ALTER TABLE `casse`
 ADD PRIMARY KEY (`caseNumber`), ADD UNIQUE KEY `nationalID` (`nationalID`);

--
-- Indexes for table `courthearing`
--
ALTER TABLE `courthearing`
 ADD PRIMARY KEY (`caseNumber`), ADD UNIQUE KEY `nationalID` (`nationalID`);

--
-- Indexes for table `fine`
--
ALTER TABLE `fine`
 ADD PRIMARY KEY (`acc_number`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
 ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
 ADD PRIMARY KEY (`nationalID`), ADD UNIQUE KEY `caseNumber` (`caseNumber`);

--
-- Indexes for table `police_station`
--
ALTER TABLE `police_station`
 ADD PRIMARY KEY (`stationID`), ADD UNIQUE KEY `nationalID` (`nationalID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
MODIFY `payment_id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `userId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
