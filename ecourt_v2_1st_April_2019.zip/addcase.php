<!DOCTYPE HTML>
<?php
	include('connect.php');
	checkPoliceOfficer();
	
	if(isset($_POST[action])&&$_POST[action]=='addTrackingDetails')
	{
		global $link;
		$national_id = addslashes($_POST[nationalID]);
		$case_number = addslashes($_POST[caseNumber]);
		$case_time = addslashes($_POST[caseTime]);
		$judge_number = addslashes($_POST[judgeNumber]);
		$prosecutor_number = addslashes($_POST[prosecutorNumber]);
		
		
		$sql = "insert into courthearing(caseNumber,nationalID,judgeNo,prosecutorNo,caseTime) value('$case_number','$national_id','$judge_number','$prosecutor_number','$case_time')";
		$result = mysql_query($sql,$link);
		if(!$result)
		{
			print "Error adding details to the system. ".mysql_error();
		}
		else
		{
			print "<h1>Data added successfully</h1>";
		}
	}
	
?>
<html>
<head>
  <title>Tracking Form</title>


</head>
<body>
      <hr>
      <?php
      	include('nav.php');
      
      ?>  
      <hr>

	<form method="POST">
	<fieldset>
	<legend>Add Case Details Form </legend>
	<input type='hidden' name='action' value='addTrackingDetails'>
	<input type="text" name="nationalID" required placeholder='National ID'> <input type="text" name="caseNumber" required placeholder='Case number'> <input type="text" name="judgeNumber" required placeholder='Judge Number'> <input type="text" name="prosecutorNumber" required placeholder='Prosecutor Number'> <input type="text" name="caseTime" required placeholder='Case time'> <input type="submit" value="Submit">
	</fieldset>
 </form>
 <hr>
 
</body>
</html>