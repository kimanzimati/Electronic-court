<!DOCTYPE HTML>
<?php
	include('connect.php');
	checkPoliceOfficer(); // This line only checks if the user is a police officer, if yes then they are knocked off the page...	+254720771584
	// $_POST[verdict], $_POST[fine], $_POST[addJudgeVerdict], $_POST[caseNumbr]
	
	global $link;


	
	if(isset($_POST[action])&&$_POST[action]=='assignCaseOfficials')
	{
		global $link;
		$judgeNumber = addslashes($_POST[judge]);
		$prosecutorNumber = addslashes($_POST[prosecutor]);
		$CaseNumber = $_POST[caseNumbr];
		$case_time = $_POST[casetime];
		
		$sql = "update courthearing SET 
		judgeNo='$judgeNumber',
		prosecutorNo='$prosecutorNumber',
		caseTime='$case_time' 
		WHERE caseNumber='$CaseNumber'";
		
		$result = mysql_query($sql,$link);
		if(!$result)
		{
			print "Error updating details to the system. ".mysql_error();
		}
		else
		{
			header('Location:hearingdetails.php?'.SID);
			print "<h1>Records updated successfully</h1>";
		}
	}
	
?>
<html>
<head>
  <title>Tracking Form</title>
<link rel='stylesheet' type='text/css' href='stylez.css'>

</head>
<body  background="images/background002.jpg">
      <hr>
      <?php
      	include('nav.php');
      ?>  
      <hr>
<?php
	// $_POST[verdict], $_POST[fine], $_POST[casefile], $_POST[caseNumbr]
	if($_GET[ref])
	{
		$theNumber = $_GET[ref];
	}
?>

	<form enctype='multipart/form-data' method="POST">
	<fieldset>
	<legend>Add Case Details Form (Judge) </legend>
	<input type='hidden' name='action' value='assignCaseOfficials'>
	<input type='hidden' name='caseNumbr' value='<?php print $theNumber;?>'>
	<select name='judge'>
	<option selected disabled>select judge...</option>
	<?php
		global $link;
		$sql = "select userId,fullname from users where rights='JUD'";
		$result = mysql_query($sql,$link);
		if(!$result)
		{
			print "Error reading system users. ".mysql_error();
		}
		else
		{
			while($row=mysql_fetch_array($result))
			{
				$jNumber = $row[userId];
				print "<option value='".$jNumber."'>".$row[fullname]."</option>";
			}
		}
	?>
	</select>
	<select name='prosecutor'>
	<option selected disabled>select prosecutor...</option>
	<?php
		global $link;
		$sql = "select userId,fullname from users where rights='PRO'";
		$result = mysql_query($sql,$link);
		if(!$result)
		{
			print "Error reading system users. ".mysql_error();
		}
		else
		{
			while($row=mysql_fetch_array($result))
			{
				$pNumber = $row[userId];
				print "<option value='".$pNumber."'>".$row[fullname]."</option>";
			}
		}
	?>
	</select>
	<input type="datetime-local" id='' value="" name='casetime'/>
	<input class='submitBox' type="submit" value="Submit">
	</fieldset>
 </form>
 <hr>
<?php
	include('footer.php');
?>
 
</body>
</html>