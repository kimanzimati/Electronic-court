<br><br><br><br><br><br><br><br><br>
<div id='footer'>
<table width=100%>
<tr>
<td><br>
	<form name='footerForm' method='POST' action='mailto:matikimanzi@gmail.com'>
	<fieldset><legend>Feedback form</legend>
		<input type='text' name='name' value='' placeholder='Your names' size=50><br>
		<input type='email' rows='15' name='email' value='' placeholder='Email' size=50><br>
		<input type='text' name='message' value='' placeholder='Your message' size=50><br>
		<input type='submit' value='SUBMIT'>
	</fieldset>
	</form>
</td>
<td align='left'>
	Email: info@e-courtsystem.org<br>
	Physical address: 14th floor Times Towers, Nairobi.<br>
	Tel: +254 720 123 123<br>
	Website: www.e-courtsystem.org<br>
</td>
</tr>
</table>
<center> 2019 &copy; E-Court System </center> 
</div>
<?php

?>
