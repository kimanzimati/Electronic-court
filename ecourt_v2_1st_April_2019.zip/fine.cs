using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
namespace Ecourt
{
    #region Fine
    public class Fine
    {
        #region Member Variables
        protected string _fullName;
        protected string _card_Type;
        protected string _national_id;
        protected string _card_number;
        protected string _acc_number;
        protected string _case_no;
        protected string _bank;
        protected int _cvs;
        protected unknown _transactionID;
        protected DateTime _date;
        #endregion
        #region Constructors
        public Fine() { }
        public Fine(string fullName, string card_Type, string card_number, string acc_number, string case_no, string bank, int cvs, unknown transactionID, DateTime date)
        {
            this._fullName=fullName;
            this._card_Type=card_Type;
            this._card_number=card_number;
            this._acc_number=acc_number;
            this._case_no=case_no;
            this._bank=bank;
            this._cvs=cvs;
            this._transactionID=transactionID;
            this._date=date;
        }
        #endregion
        #region Public Properties
        public virtual string FullName
        {
            get {return _fullName;}
            set {_fullName=value;}
        }
        public virtual string Card_Type
        {
            get {return _card_Type;}
            set {_card_Type=value;}
        }
        public virtual string National_id
        {
            get {return _national_id;}
            set {_national_id=value;}
        }
        public virtual string Card_number
        {
            get {return _card_number;}
            set {_card_number=value;}
        }
        public virtual string Acc_number
        {
            get {return _acc_number;}
            set {_acc_number=value;}
        }
        public virtual string Case_no
        {
            get {return _case_no;}
            set {_case_no=value;}
        }
        public virtual string Bank
        {
            get {return _bank;}
            set {_bank=value;}
        }
        public virtual int Cvs
        {
            get {return _cvs;}
            set {_cvs=value;}
        }
        public virtual unknown TransactionID
        {
            get {return _transactionID;}
            set {_transactionID=value;}
        }
        public virtual DateTime Date
        {
            get {return _date;}
            set {_date=value;}
        }
        #endregion
    }
    #endregion
}