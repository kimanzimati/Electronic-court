-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2019 at 03:56 PM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ecourt`
--

-- --------------------------------------------------------

--
-- Table structure for table `casedetails`
--

CREATE TABLE IF NOT EXISTS `casedetails` (
  `hearingID` varchar(50) NOT NULL,
  `caseNumber` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `defendant_ID` varchar(50) DEFAULT NULL,
  `time` time NOT NULL,
  `policeStation` varchar(50) NOT NULL,
  `policeID` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `casse`
--

CREATE TABLE IF NOT EXISTS `casse` (
  `caseNumber` varchar(50) NOT NULL,
  `policeStation` varchar(50) NOT NULL,
  `policeID` int(30) DEFAULT NULL,
  `nationalID` varchar(50) NOT NULL,
  `offence` varchar(50) NOT NULL,
  `email` text NOT NULL,
  `gender` text NOT NULL,
  `names` text NOT NULL,
  `timeOfEntry` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `casse`
--

INSERT INTO `casse` (`caseNumber`, `policeStation`, `policeID`, `nationalID`, `offence`, `email`, `gender`, `names`, `timeOfEntry`) VALUES
('1001001', 'Kitale', 0, '007', 'DUI', 'james.bond@gmail.com', 'm', 'James Bond', '2019-03-04 10:00:00'),
('1001001RTS', 'Kabete', 0, '00790', 'Loitering', 'j.chan@hotmail.com', 'm', 'Jacky Chan', '2019-03-08 11:24:26'),
('2001001RTS', 'Muthaiga', 0, '070087335', 'DUI', 'titus.omondi@hotmail.com', 'm', 'Titus Omondi', '2019-03-01 16:38:48'),
('AAR100123', 'Westlands', 0, '9879979', 'Carjacking', 'lucy.wangui@gmail.com', 'f', 'Lucy Wangui', '2019-03-20 13:32:00'),
('AAR100124', 'Kitisuru', 0, '070087332', 'Pick-pocketing', 'm.kiunjuri@excite.com', 'm', 'Mwangi Kiunjuri', '2019-03-19 06:24:22'),
('LTZ123', 'Githurai', 0, '22334455', 'Literring', 'a.lucy@hotmail.com', 'f', 'Lucy Achieng', '2019-03-11 17:20:34');

-- --------------------------------------------------------

--
-- Table structure for table `courthearing`
--

CREATE TABLE IF NOT EXISTS `courthearing` (
  `caseNumber` varchar(50) NOT NULL,
  `judgeNo` varchar(50) NOT NULL,
  `nationalID` varchar(10) NOT NULL,
  `caseTime` time NOT NULL,
  `prosecutorNo` varchar(50) NOT NULL,
  `caseVerdict` varchar(100) DEFAULT NULL,
  `hearingID` varchar(10) NOT NULL,
  `fine` varchar(50) NOT NULL,
  `attachment` text NOT NULL,
  `dateOfEntry` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courthearing`
--

INSERT INTO `courthearing` (`caseNumber`, `judgeNo`, `nationalID`, `caseTime`, `prosecutorNo`, `caseVerdict`, `hearingID`, `fine`, `attachment`, `dateOfEntry`) VALUES
('A978797999', 'A321', '23257278', '15:30:00', 'P001', NULL, 'AK001', '', '', '2019-03-01 06:28:20'),
('A987989890', 'A123', '12345678', '15:45:00', 'P001', NULL, 'AK002', '', '', '2019-03-04 06:20:23'),
('BZ9988998', 'A321', '33280296', '16:00:00', 'P002', NULL, 'AK003', '', '', '2019-03-05 05:10:09'),
('RTF20330', 'BK021', '99887766', '16:20:00', 'P003', 'DISMISSED', 'AZ003', '0', 'casefiles/kra error screen.pdf', '2019-03-13 11:18:29'),
('TRM1001', '101', '987997901', '10:30:00', 'P-001', 'GUILTY', '', '5000', 'casefiles/844__New_Syllabus.pdf', '2019-03-12 06:19:23'),
('TRM1002', 'J-101', 'RTF20331', '11:30:00', 'P-002', 'GUILTY', '', '150000', 'casefiles/dwarfs.png', '2019-03-10 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE IF NOT EXISTS `person` (
  `nationalID` varchar(10) NOT NULL,
  `fName` varchar(50) NOT NULL,
  `lName` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `offence` varchar(100) NOT NULL,
  `caseNumber` varchar(50) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `policeStation` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`nationalID`, `fName`, `lName`, `password`, `offence`, `caseNumber`, `email`, `policeStation`, `status`) VALUES
('33280296', 'kim', 'mati', 'a1', 'trespassing', 'A124FER', 'a@gmail.com', 'Ruiru', 'criminal');

-- --------------------------------------------------------

--
-- Table structure for table `police_station`
--

CREATE TABLE IF NOT EXISTS `police_station` (
  `stationID` varchar(50) NOT NULL,
  `police_fname` varchar(50) NOT NULL,
  `police_lname` varchar(50) NOT NULL,
  `policeStation` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nationalID` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`userId` bigint(20) NOT NULL,
  `fullname` text NOT NULL,
  `national_id` bigint(20) DEFAULT NULL,
  `gender` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `rights` text NOT NULL,
  `email` text NOT NULL,
  `mobile_number` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `fullname`, `national_id`, `gender`, `username`, `password`, `rights`, `email`, `mobile_number`) VALUES
(1, 'Don Ochieng''', 13288899, '', 'don', '*804424B6DD59417627E949DBF18C32D7D08A86C7', 'POL', 'donochi@gmail.com', '+254720231104'),
(2, 'Steve Muema', 97899879, 'm', 'steve', '*D95CCB971C6834A1500A36AB765D187226A7818C', 'JUD', 'steve.muema@gmail.com', '+254735200458'),
(3, 'John Akombe', 12377690, 'm', 'jakombe', '*DACDE7F5744D3CB439B40D938673B8240B824853', 'PRO', 'akombej@yahoo.co.uk', '+254713675890'),
(4, 'Phillip Otieno', 12344321, 'm', 'phillip', '*C203B2C53722D75171B711DCAFA1CE6F23D6F590', 'ADM', 'p.otieno@yahoo.com', '+254735200458'),
(5, 'Susan Mwangi', 12344324, 'f', 'susan', '*C391980232FA468D6B1C82BC2A6D4DEB18AF4D21', 'CRI', 's.mwangi@gmail.com', '+254735200458'),
(6, 'Lucy Achieng', 22334455, 'f', 'lucy', '*CB89BB054D1BED69BF24CA582FADEEBBBAD132CC', 'CRI', 'a.lucy@hotmail.com', '+254712345678');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `casedetails`
--
ALTER TABLE `casedetails`
 ADD PRIMARY KEY (`hearingID`), ADD UNIQUE KEY `caseNumber` (`caseNumber`);

--
-- Indexes for table `casse`
--
ALTER TABLE `casse`
 ADD PRIMARY KEY (`caseNumber`), ADD UNIQUE KEY `nationalID` (`nationalID`);

--
-- Indexes for table `courthearing`
--
ALTER TABLE `courthearing`
 ADD PRIMARY KEY (`caseNumber`), ADD UNIQUE KEY `nationalID` (`nationalID`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
 ADD PRIMARY KEY (`nationalID`), ADD UNIQUE KEY `caseNumber` (`caseNumber`);

--
-- Indexes for table `police_station`
--
ALTER TABLE `police_station`
 ADD PRIMARY KEY (`stationID`), ADD UNIQUE KEY `nationalID` (`nationalID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `userId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
