<!DOCTYPE HTML>
<?php
	include('connect.php');
	checkPoliceOfficer(); // This line only checks if the user is a police officer, if yes then they are knocked off the page...
	// $_POST[verdict], $_POST[fine], $_POST[addJudgeVerdict], $_POST[caseNumbr]
	// $_POST[verdict], $_POST[fine], $_POST[casefile], $_POST[caseNumbr], $_POST[vLink]
	
	global $link;


	
	if(isset($_POST[action])&&$_POST[action]=='addJudgeVerdict')
	{
		global $link;
		$verdict = addslashes($_POST[verdict]);
		$fine = addslashes($_POST[fine]);
		$CaseNumber = addslashes($_POST[caseNumbr]);
		$video_link = addslashes($_POST[vLink]);

		$thefile = addslashes($_FILES[casefile][name]);
		$filePath = 'casefiles/'.$thefile;
		if(!$_FILES[casefile][name])
		{
			$filePath = "";
		}
		if($_FILES[casefile][tmp_name])
		{
			if(!move_uploaded_file($_FILES[casefile][tmp_name],$filePath))
			{
				$reply = "<div id='alert'> Error copying the teacher resume into the system.</div>";
			}
		}
		
		$sql = "update courthearing SET 
		caseVerdict='$verdict',
		videolink='$video_link',
		fine='$fine',
		attachment='$filePath' WHERE caseNumber='$CaseNumber'";
		
		$result = mysql_query($sql,$link);
		if(!$result)
		{
			print "Error adding details to the system. ".mysql_error();
		}
		else
		{
			header('Location:hearingdetails.php?'.SID);
			print "<h1>Records updated successfully</h1>";
		}
	}
	
?>
<html>
<head>
  <title>Tracking Form</title>


</head>
<body  background="images/straws_2X.png">
      <hr>
      <?php
      	include('nav.php');
      ?>  
      <hr>
<?php
	// $_POST[verdict], $_POST[fine], $_POST[casefile], $_POST[caseNumbr], $_POST[vLink]
	if($_GET[number])
	{
		$theNumber = $_GET[number];
	}
?>

	<form enctype='multipart/form-data' method="POST">
	<fieldset>
	<legend>Add Case Details Form (Judge) </legend>
	<input type='hidden' name='action' value='addJudgeVerdict'>
	<input type='hidden' name='caseNumbr' value='<?php print $theNumber;?>'>
	<select name='verdict'>
	<option selected disabled>Verdict</option>
	<option>DISMISSED</option>
	<option>GUILTY</option>
	<option>PENDING</option>
	<input type="text" name="fine" required placeholder='fine'> <input type="text" name="vLink" required placeholder='video link...'><input name="casefile" type="file" size="5" value=""> <input type="submit" value="Submit">
	</fieldset>
 </form>
 <hr>
 
</body>
</html>