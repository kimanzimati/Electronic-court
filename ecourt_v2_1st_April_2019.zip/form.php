<!DOCTYPE HTML>
<?php
	include('connect.php');
	checkPoliceOfficer(); // This line only checks if the user is a police officer, if yes then they are knocked off the page...
	checkCriminal(); // This line only checks if the user is a accused person, if yes then they are knocked off the page...
	checkProsecutor(); // This line only checks if the user is a prosecutor, if yes then they are knocked off the page...
	checkJudge(); // This line only checks if the user is a judge, if yes then they are knocked off the page...
	// The only user allowed on this page is the system administrator...
	
	if(isset($_POST[action])&&$_POST[action]=='addUser')
	{
		global $link;
		$fullNames = $_POST[fullName];
		$names = $_POST[username];
		$passWord = $_POST[password];
		$userRights = $_POST[rights];
		$gender = $_POST[gender];
		$email = $_POST[email];
		$nationalID = $_POST[national_id];
		$phoneCode = $_POST[phoneCode];
		$cellphoneNumber = $_POST[phone];
		$completeCellphoneNumber = $phoneCode.''.$cellphoneNumber;
		$offens = $_POST[offence];
		$police_id = $_POST[policeID];
		
		$sql = "insert into users(fullname,national_id,gender,username,password,rights,email,mobile_number) value('$fullNames','$nationalID','$gender','$names',PASSWORD('$passWord'),'$userRights','$email','$completeCellphoneNumber')";
		$result = mysql_query($sql,$link);
		if(!$result)
		{
			print "Error adding user details to the system. ".mysql_error();
		}
		else
		{
			print "<h1>New User data added successfully</h1>";
		}
	}
	
?>

<html>
<head>
  <title>Sign up Form</title>
	<link rel='stylesheet' type='text/css' href='stylez.css'>
</head>
<body background="images/background002.jpg">
<hr>
<?php
	include('nav.php');
?>
<hr>
 <form method="POST">
	<input type='hidden' name='action' value='addUser'>
  <table>
   <tr>
    <td>Full Names :</td>
    <td><input type="text" name="fullName" required></td>
   </tr>
   <tr>
    <td>Rights :</td>
    <td>
		<select name='rights'>
			<option selected disabled>User rights</option>
			<option value='ADM'>Admin</option>
			<option value='JUD'>Judge</option>
			<option value='POL'>Police Officer</option>
			<option value='PRO'>Prosecutor</option>
			<option value='CRI'>Accussed</option>
		</select>
	</td>
   </tr>

   <tr>
    <td>Username :</td>
    <td><input type="text" name="username" required></td>
   </tr>
   <tr>
    <td>Password :</td>
    <td><input type="text" name="password" required></td>
   </tr>
   <tr>
    <td>Gender :</td>
    <td>
     <input type="radio" name="gender" value="m" required>Male
     <input type="radio" name="gender" value="f" required>Female
    </td>
   </tr>
   <tr>
    <td>Email :</td>
    <td><input type="email" name="email" required></td>
   </tr> 
   <tr>
    <td>National ID :</td>
    <td><input type="text" name="national_id" required></td>
   </tr> 
   <tr>
    <td>Phone no :</td>
    <td>
     <select name="phoneCode" required>
      <option selected hidden value="">Select Code</option>
      <option value="+254">+254</option>
     </select>
     <input type="phone" name="phone" required>
    </td>
   </tr>
   <tr>
    <td><input type="submit" value="Submit"></td>
   </tr>
  </table>
 </form>
</body>
</html>