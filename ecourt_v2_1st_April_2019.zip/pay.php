<!DOCTYPE HTML>
<?php
	include('connect.php');
	checkPoliceOfficer(); // This line only checks if the user is a police officer with rights, if not they are knocked off the page...
	 // $_POST[fullName], $_POST[emailAddress], $_POST[billingAddress], $_POST[city], $_POST[state], $_POST[zcode], $_POST[cardNo], $_POST[amount]
	 
	if(isset($_POST[action])&&$_POST[action]=='addNewPayment')
	{
		global $link;
		$fullNames = $_POST[fullName];
		$email = $_POST[emailAddress];
		$billAddress = $_POST[billingAddress];
		$city = $_POST[city];
		$state = $_POST[state];
		$zCode = $_POST[zcode];
		$card_no = $_POST[cardNo];
		$amnt = $_POST[amount];
		
		$sql = "insert into payment(fullname,national_id,gender,username,password,rights,email,mobile_number) value('$fullNames','$nationalID','$gender','$names',PASSWORD('$passWord'),'$userRights','$email','$completeCellphoneNumber')";
		$result = mysql_query($sql,$link);
		if(!$result)
		{
			print "Error adding user details to the system. ".mysql_error();
		}
		else
		{
			print "<h1>New User data added successfully</h1>";
		}
	}
	
?>

<html>
<head>
  <title>Pay-up Form</title>
</head>
<body  background="images/background002.jpg">
<hr>
<?php
	include('nav.php'); // $_POST[fullName], $_POST[emailAddress], $_POST[billingAddress], $_POST[city], $_POST[state], $_POST[zcode], $_POST[cardNo], $_POST[amount]
?>
<hr>
 <form method="POST">
	<input type='hidden' name='action' value='addNewPayment'>
  <table>
   <tr>
    <td>Full Names :</td>
    <td><input type="text" name="fullName" required></td>
   </tr>

   <tr>
    <td>Email :</td>
    <td><input type="email" name="emailAddress" required></td>
   </tr>
   <tr>
    <td>Billing address :</td>
    <td><input type="text" name="billingAddress" required></td>
   </tr>
   <tr>
    <td>City :</td>
    <td><input type="email" name="city" required></td>
   </tr> 
   <tr>
    <td>State :</td>
    <td><input type="text" name="state" required></td>
   </tr> 
   <tr>
    <td>Zip-code :</td>
    <td><input type="text" name="zcode" required></td>
   </tr> 
   <tr>
    <td>Card No :</td>
    <td><input type="text" name="cardNo" required></td>
   </tr> 
  <tr>
    <td>Amount (KES) :</td>
    <td><input type="text" name="amount" required></td>
   </tr> 

   <tr>
    <td><input type="submit" value="Submit"></td>
   </tr>
  </table>
 </form>
</body>
</html>