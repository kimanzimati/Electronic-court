<!DOCTYPE html>
<?php
	include('connect.php');
?>
<html>
	<head>
<link rel='stylesheet' type='text/css' href='stylez.css'>
		<meta charset="utf-8">
		<title>Login Form Tutorial</title>
	</head>
	<body background="images/background002.jpg">
	<?php
		if(isset($_POST[password])&&isset($_POST[username]))
		{
			print "User logged in successfull... ";
			global $link;
			$user =  $_POST[username];
			$pass =  $_POST[password];
			print "Username is ".$user;
			print "Password is ".$pass;
			
			$sql = "select * from users where username='$user' AND password=PASSWORD('$pass')";
			$result = mysql_query($sql,$link);
			if(!$result)
			{
				print "Error connecting to the db. ".mysql_error();
			}
			else
			{
				while($row=mysql_fetch_array($result))
				{
					global $session;
					$session['thisUser'] = $row[fullname];
					$session['email'] = $row[email];
					$session['loginStatus'] = "logged_in";
					$session['cellphone'] = $row[mobile_number];
					$session['userRights'] = $row[rights];
					$_SESSION[session] = $session;
				}
				print $session[thisUser];
				header('Location:index.php?'.SID);
				$thisSession = $_SESSION[session];
				$test = $thisSession[cellphone];
				print "User logged in successfull... ".$test;
			}
		}
	?>
		<div class="">
			<form  method="post" id='loginform'>
				<fieldset><legend>Login Form</legend>
				<input type="hidden" name="action" value="loginuser">
				<input type="text" name="username" placeholder="Username" autofocus required>
				<input type="password" name="password" placeholder="Password" required>
				<input type="submit" value="Login">
				<?php
					// print "And the username is ".$_POST[username];
				?>
				</fieldset>
				
			</form>
		</div>
	</body>
</html>